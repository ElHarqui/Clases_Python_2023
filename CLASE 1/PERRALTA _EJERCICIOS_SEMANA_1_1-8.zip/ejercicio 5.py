"""5. Realice un programa que imprima la ubicación de su carpeta donde se encuentra
trabajando.
Nota : agregar el siguiente código
1. import sys
2. variable =sys.argv[0]"""
import sys
variable = sys.argv[0]
print("AQUI COMIENZA \n\t ",variable)

