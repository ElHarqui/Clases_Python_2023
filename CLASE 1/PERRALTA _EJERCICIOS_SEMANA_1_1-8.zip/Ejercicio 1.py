#Peralta Silvano, Sebastian Leonardo
#1.Realizar un programa que ingrese sus datos personales e imprimirlos.

nombre = input('Ingrese nombre : ')
edad = input('Ingrese edad : ')
dni = input('Ingrese Nº de DNI : ')
print(nombre, edad, dni)
