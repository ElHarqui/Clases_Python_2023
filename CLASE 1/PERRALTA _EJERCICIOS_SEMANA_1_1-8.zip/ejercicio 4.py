#4.Ingrese un valor e imprima el tipo de dato.
valR = int(input('ingrese dato : '))
print(type(valR))

