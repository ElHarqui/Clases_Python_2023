#3.Ingrese 3 valores y realice las operaciones de suma ,resta ,multiplicación, división y división entera.

vaL1=int(input('Ingrese valor 1 : '))
vaL2=int(input('Ingrese valor 2 : '))
vaL3=int(input('Ingrese valor 3 : '))

suma = vaL1+ vaL2 + vaL3
resta = vaL1 - vaL2 - vaL3
multi = (vaL1 + vaL2)* vaL3
divid = (vaL1 +vaL2)/ vaL3
dividEN = (vaL1 +vaL2)// vaL3
print(suma,'\n' , resta, '\n' ,multi, '\n' , divid ,'\n',  dividEN)

